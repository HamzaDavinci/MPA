<!DOCTYPE html>
<html lang="en" class="bg-background-main text-[#fafafa]">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Bugify - Playlists</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>
<body class="flex flex-col min-h-screen">

    <?php echo $__env->make('navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="flex-grow container mx-auto px-4 py-8 max-w-5xl">
        <h1 class="text-4xl font-bold mb-8 text-spotify-green">Your Playlists</h1>

        <?php if(session('success')): ?>
            <div class="mb-6 p-4 rounded bg-green-600 text-white">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="mb-6 p-4 rounded bg-red-600 text-white">
                <ul class="list-disc list-inside">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>


        <form id="playlistForm" method="POST" action="<?php echo e(route('playlists.store')); ?>" class="mb-12 bg-background-surface p-6 rounded-xl shadow-lg">
            <?php echo csrf_field(); ?>

            <label for="name" class="block mb-2 font-semibold text-[#fafafa]">New playlist name</label>
            <input id="name" name="name" type="text" placeholder="Name" required
                class="w-full p-3 mb-4 rounded bg-background-main border border-gray-700 text-[#fafafa] focus:outline-none focus:ring-2 focus:ring-spotify-green" />

            <div class="mb-4">
                <p class="mb-2 font-semibold text-[#fafafa]">Select music to add:</p>
                <div class="max-h-64 overflow-y-auto bg-background-main p-3 rounded scrollbar-custom">
                    <?php $__currentLoopData = $music; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label class="flex items-center justify-between space-x-3 mb-2 cursor-pointer hover:bg-background-surface/50 rounded px-2 py-1">
                            <div class="flex items-center space-x-2">
                                <input type="checkbox" name="music_ids[]" value="<?php echo e($song->id); ?>" class="accent-spotify-green" />
                                <span><?php echo e($song->title); ?></span>
                            </div>
                            <div class="text-sm text-gray-400 flex space-x-4">
                                <span><?php echo e($song->genre->name ?? 'Unknown Genre'); ?></span>
                                <span><?php echo e(floor($song->duration / 60)); ?>:<?php echo e(str_pad($song->duration % 60, 2, '0', STR_PAD_LEFT)); ?></span>
                            </div>
                        </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <button type="submit"
                class="bg-spotify-green hover:bg-spotify-green-dark text-background-main font-bold py-3 px-6 rounded-xl transition-all duration-200">
                Save
            </button>
        </form>

        <section>
            <h2 class="text-3xl font-bold mb-6 text-spotify-green">Existing Playlists</h2>

            <?php if($playlists->isEmpty()): ?>
                <p class="text-gray-400">You have no playlists yet.</p>
            <?php else: ?>
                <div class="space-y-4">
                    <?php $__currentLoopData = $playlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $playlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $playlistMusic = $playlist->music;
                            $totalDuration = $playlistMusic->sum('duration');
                            $hours = floor($totalDuration / 3600);
                            $minutes = floor(($totalDuration % 3600) / 60);
                        ?>

                        <details class="bg-background-surface rounded-xl shadow p-4">
                            <summary class="cursor-pointer font-semibold text-xl truncate text-spotify-green select-none">
                                <?php echo e($playlist->name); ?> (<?php echo e($playlistMusic->count()); ?> songs,
                                total: <?php echo e($hours); ?>u <?php echo e(str_pad($minutes, 2, '0', STR_PAD_LEFT)); ?>m)
                            </summary>

                            <ul class="mt-3 max-h-48 overflow-y-auto pl-5 list-disc scrollbar-custom text-[#fafafa] space-y-1">
                                <?php $__currentLoopData = $playlistMusic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="flex justify-between">
                                        <span><?php echo e($song->title); ?></span>
                                        <span class="text-sm text-gray-400">
                                            <?php echo e($song->genre->name ?? 'Unknown Genre'); ?> –
                                            <?php echo e(floor($song->duration / 60)); ?>:<?php echo e(str_pad($song->duration % 60, 2, '0', STR_PAD_LEFT)); ?>

                                        </span>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>

                            <button
                                onclick='editPlaylist(<?php echo e($playlist->id); ?>, <?php echo e(json_encode($playlist->name)); ?>, <?php echo e(json_encode($playlist->music->pluck("id"))); ?>)'
                                class="mt-4 bg-spotify-green hover:bg-spotify-green-dark text-background-main font-bold py-2 px-5 rounded-xl transition-all duration-200"
                            >
                                Edit
                            </button>

                            <form method="POST" action="<?php echo e(route('playlists.destroy', $playlist->id)); ?>" onsubmit="return confirm('Are you sure you want to delete this playlist?')" class="inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit"
                                    class="mt-2 ml-3 bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-5 rounded-xl transition-all duration-200">
                                    Delete
                                </button>
                            </form>
                        </details>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </section>


        <div id="editFormWrapper" class="mt-12 hidden">
            <h2 class="text-3xl font-bold mb-4 text-spotify-green">Edit Playlist</h2>
            <form id="editPlaylistForm" method="POST" class="bg-background-surface p-6 rounded-xl shadow-lg">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>

                <label for="editName" class="block mb-2 font-semibold text-[#fafafa]">Naam</label>
                <input id="editName" name="name" type="text" required
                    class="w-full p-3 mb-4 rounded bg-background-main border border-gray-700 text-[#fafafa] focus:outline-none focus:ring-2 focus:ring-spotify-green" />

                <p class="mb-2 font-semibold text-[#fafafa]">Muziek selecteren:</p>
                <div class="max-h-64 overflow-y-auto bg-background-main p-3 rounded scrollbar-custom mb-4">
                    <?php $__currentLoopData = $music; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label class="flex items-center justify-between space-x-3 mb-2 cursor-pointer hover:bg-background-surface/50 rounded px-2 py-1">
                            <div class="flex items-center space-x-2">
                                <input type="checkbox" class="edit-music-checkbox accent-spotify-green" name="music_ids[]" value="<?php echo e($song->id); ?>">
                                <span><?php echo e($song->title); ?></span>
                            </div>
                            <div class="text-sm text-gray-400 flex space-x-4">
                                <span><?php echo e($song->genre->name ?? 'Unknown Genre'); ?></span>
                                <span><?php echo e(floor($song->duration / 60)); ?>:<?php echo e(str_pad($song->duration % 60, 2, '0', STR_PAD_LEFT)); ?></span>
                            </div>
                        </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <button type="submit"
                    class="bg-spotify-green hover:bg-spotify-green-dark text-background-main font-bold py-3 px-6 rounded-xl transition-all duration-200">
                    Update
                </button>
            </form>
        </div>

    </main>

    <?php echo $__env->make('footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<script>
document.addEventListener('DOMContentLoaded', () => {
    // Validatie bij aanmaken playlist
    const createForm = document.getElementById('playlistForm');
    if (createForm) {
        createForm.addEventListener('submit', e => {
            const checked = createForm.querySelectorAll('input[name="music_ids[]"]:checked');
            if (checked.length === 0) {
                e.preventDefault();
                alert('Add at least 1 music to your playlist.');
            }
            
        });
    }

    // Validatie bij updaten playlist
    const editForm = document.getElementById('editPlaylistForm');
    if (editForm) {
        editForm.addEventListener('submit', e => {
            const checked = editForm.querySelectorAll('input[name="music_ids[]"]:checked');
            if (checked.length === 0) {
                e.preventDefault();
                alert('Add at least 1 music to your playlist.');
            }
        });
    }
});

function editPlaylist(id, name, selectedMusic) {
    document.getElementById('editFormWrapper').classList.remove('hidden');
    const form = document.getElementById('editPlaylistForm');
    const nameInput = document.getElementById('editName');
    const checkboxes = form.querySelectorAll('.edit-music-checkbox');

    form.action = `/playlists/${id}`;
    nameInput.value = name;

    // Zorg dat alle IDs numbers zijn
    selectedMusic = selectedMusic.map(id => parseInt(id));

    checkboxes.forEach(cb => {
        const cbValue = parseInt(cb.value);
        cb.checked = selectedMusic.includes(cbValue);
    });

    window.scrollTo({ top: form.offsetTop - 50, behavior: 'smooth' });
}
</script>

</body>
</html>
<?php /**PATH C:\school\MPA\bugify\resources\views/playlists.blade.php ENDPATH**/ ?>