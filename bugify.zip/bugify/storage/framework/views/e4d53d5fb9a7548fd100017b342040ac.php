<footer class="bg-background-surface p-4 text-center text-sm text-gray-500">
    © <?php echo(date("Y"))?> Bugify Inc. Proudly broken. - Made By 
    <a href="https://hamzq.dev" target="_blank" rel="noopener noreferrer" class="text-spotify-green hover:underline">
        Hamzq
    </a>
</footer>
<?php /**PATH C:\school\MPA\bugify\resources\views/footer.blade.php ENDPATH**/ ?>