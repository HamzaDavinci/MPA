<!DOCTYPE html>
<html lang="en" class="bg-background-main text-[#fafafa] font-sans">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title><?php echo e($title ?? 'Bugify'); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>
<body class="min-h-screen flex flex-col">

    
    <?php echo $__env->make('navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <?php if(session('status')): ?>
        <div class="bg-green-600 text-white text-center py-2">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    
    <?php if(isset($header)): ?>
        <header class="bg-background-surface shadow p-6 rounded-xl max-w-7xl mx-auto w-full mt-6">
            <?php echo e($header); ?>

        </header>
    <?php endif; ?>

    
    <main class="flex-1 max-w-7xl mx-auto w-full p-6 sm:p-10 mt-6">
        <?php echo e($slot); ?>

    </main>

    
    <?php echo $__env->make('footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</body>
</html>
<?php /**PATH C:\school\MPA\bugify\resources\views/layouts/app.blade.php ENDPATH**/ ?>